//// Assets/Editor/StoryDataValidator.cs
//using System.Linq;
//using System.Collections.Generic;
//using UnityEditor;
//using UnityEngine;

//public static class StoryDataValidator
//{
//    // ������ Ÿ�� ����
//    static readonly HashSet<string> ExecTypes = new() { "MERCHANT", "BATTLE", "IMAGE", "CLAER" };

//    [MenuItem("Tools/Story/Validate MainStory Data")]
//    public static void Validate()
//    {
//        var jm = Object.FindObjectOfType<JsonManager>();
//        if (jm == null)
//        {
//            Debug.LogError("[Validator] JsonManager�� ���� ����");
//            return;
//        }

//        var stories = jm.GetStoryMainMasters("Story_Master_Main") ?? new List<Story_Master_Main>();
//        var scripts = jm.GetStoryMainScriptMasters("Main_Script_Master_Main") ?? new List<Main_Script_Master_Main>();

//        // SceneCode �� Row ��
//        var byScene = stories.GroupBy(s => s.Scene_Code?.Trim())
//                             .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Script_Index).ToList());

//        // ScriptCode �� Meta ��
//        var meta = scripts.GroupBy(s => s.Script_Code?.Trim())
//                          .ToDictionary(g => g.Key, g => g.First());

//        int warn = 0;

//        foreach (var row in stories)
//        {
//            string scene = row.Scene_Code?.Trim();
//            string scriptCode = row.Script_Text?.Trim();

//            // ��ũ��Ʈ ��Ÿ Ȯ��
//            if (!string.IsNullOrEmpty(scriptCode) && meta.TryGetValue(scriptCode, out var m))
//            {
//                // �������ε� Next_Scene�� ä���� ������ ��� (�ǵ��� �б����� Ȯ���϶�� �ȳ�)
//                if (ExecTypes.Contains(m.displayType?.Trim()))
//                {
//                    if (!string.IsNullOrWhiteSpace(row.Next_Scene))
//                    {
//                        Debug.LogWarning($"[Validator] ������ �� Next_Scene ����: {scene} -> {row.Next_Scene} (type={m.displayType})");
//                        warn++;
//                    }
//                }
//            }
//            else
//            {
//                Debug.LogWarning($"[Validator] ��ũ��Ʈ ��Ÿ�� ã�� ����: Scene={scene}, Script={scriptCode}");
//                warn++;
//            }

//            // Next_Scene ��ȿ�� üũ
//            if (!string.IsNullOrWhiteSpace(row.Next_Scene))
//            {
//                string next = row.Next_Scene.Trim();
//                if (!byScene.ContainsKey(next))
//                {
//                    Debug.LogWarning($"[Validator] Next_Scene ��� ����: {scene} -> {next}");
//                    warn++;
//                }
//                else
//                {
//                    // �ٷ� Break�� �������� ���� ��ĵ(ù ��� ��Ÿ Ȯ��)
//                    var nextRow = byScene[next].First();
//                    var nextCode = nextRow.Script_Text?.Trim();
//                    if (!string.IsNullOrEmpty(nextCode) && meta.TryGetValue(nextCode, out var nm))
//                    {
//                        if ((nm.StoryBreak?.Trim()) == "Break")
//                        {
//                            Debug.LogWarning($"[Validator] Next_Scene ���� ��� Break �ǽ�: {scene} -> {next} (Script={nextCode})");
//                            warn++;
//                        }
//                    }
//                }
//            }
//        }

//        if (warn == 0) Debug.Log("[Validator] �̻� ����.");
//        else Debug.Log($"[Validator] ��� {warn}��. �ܼ� �α� ����.");
//    }
//}
