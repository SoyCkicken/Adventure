using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class ConfirmPopup : MonoBehaviour
{
    public static ConfirmPopup Instance;

    [Header("UI Components")]
    public TextMeshProUGUI messageText;
    public Button yesButton;
    public Button noButton;

    private void Awake()
    {
        gameObject.SetActive(true);
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        gameObject.SetActive(false);
    }

    public static void Show(string message, Action onConfirm)
    {
        if (Instance == null)
        {
            Debug.LogError("[ConfirmPopup] �������� ���� �������� �ʽ��ϴ�.");
            return;
        }

        Instance.gameObject.SetActive(true);
        Instance.messageText.text = message;

        // ���� ������ ����
        Instance.yesButton.onClick.RemoveAllListeners();
        Instance.noButton.onClick.RemoveAllListeners();

        // �� ��ư
        Instance.yesButton.onClick.AddListener(() =>
        {
            onConfirm?.Invoke();
            Instance.gameObject.SetActive(false);
        });

        // �ƴϿ� ��ư
        Instance.noButton.onClick.AddListener(() =>
        {
            Instance.gameObject.SetActive(false);
        });
    }
}
