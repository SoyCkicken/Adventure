using Spine;
using Spine.Unity;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class TESTBoss : MonoBehaviour
{
    [Header("�⺻ ����")]
    public BossPartCombatManager BossPartCombatManager;
    public SkeletonAnimation skeletonAnimation;
    public string bossName;
    public int attackPower = 50;
    public int MaxTotalHP;
    public int CurrentTotalHP;
    public int hitChance = 80;

    // �׷� Ű���� (��, �ٸ� ��)
    private readonly string[] armGroupKeys = { "��" };
    private readonly string[] legGroupKeys = { "�ٸ�" };

    [Header("���� ����")]
    public List<PartInfo> partList = new();

    private Dictionary<string, MonsterPart> parts = new();
    public bool IsDead => CurrentTotalHP <= 0;
    private bool isAttackDisabled = false;

    void Start()
    {
        CurrentTotalHP = MaxTotalHP;
       var skeleton = skeletonAnimation.skeleton;
        foreach (var part in partList)
        {
            if (part.partName.Contains("�Ӹ�"))
            {
                RegisterPart(part.partName, part.hp, part.EvadeRate, () =>
                {
                    BossPartCombatManager.Log("[Boss] �Ӹ� ������ �ı��Ǿ����ϴ�. ��� ó����!\n");
                    skeleton.FindSlot(part.slotName).Attachment = null;
                    Kill();
                    PlayDeathAnimation();
                });
            }
            else
            {
                RegisterPart(part.partName, part.hp, part.EvadeRate, () =>
                {
                    BossPartCombatManager.Log($"[Boss] {part.partName} ������ �ı��Ǿ����ϴ�!\n");
                    skeleton.FindSlot(part.slotName).Attachment = null;
                    // �ı� ���� üũ
                    CheckArmCondition();
                    CheckLegCondition();
                });
            }
        }
    }

    private List<string> GetPartNamesContaining(params string[] keywords)
    {
        List<string> result = new();
        foreach (var kv in parts)
        {
            foreach (var keyword in keywords)
            {
                if (kv.Key.Contains(keyword))
                {
                    result.Add(kv.Key);
                    break;
                }
            }
        }
        return result;
    }

    private void CheckArmCondition()
    {
        var armParts = GetPartNamesContaining(armGroupKeys);
        Debug.Log(armParts.Count);
        bool allArmsBroken = armParts.All(partName => IsPartBroken(partName));

        if (allArmsBroken)
        {
            isAttackDisabled = true;
            BossPartCombatManager.Log("[Boss] ��� ���� �ı��Ǿ� ������ �� �����ϴ�.\n");
        }
    }

    private void CheckLegCondition()
    {
        var legParts = GetPartNamesContaining(legGroupKeys);
        Debug.Log(legParts.Count);
        bool allLegsBroken = legParts.All(partName => IsPartBroken(partName));

        if (allLegsBroken && parts.ContainsKey("�Ӹ�"))
        {
            parts["�Ӹ�"].EvadeRate = 0;
            BossPartCombatManager.Log("[Boss] ��� �ٸ��� �ı��Ǿ� �Ӹ� ȸ������ 0%�� ����Ǿ����ϴ�.\n");
        }
    }   

    public void RegisterPart(string name, int hp, int evadeRate, System.Action onBreak)
    {
        parts[name] = new MonsterPart(name, hp, evadeRate, onBreak);
    }

    public void DamagePart(string name, int amount)
    {
        if (!parts.ContainsKey(name)) return;
        if (IsDead) return;
        var skeletonAnim = skeletonAnimation.GetComponent<SkeletonAnimation>();
        parts[name].Damage(amount);
        CurrentTotalHP -= amount;
        skeletonAnim.AnimationState.SetAnimation(0, "Hit", false);
        if (CurrentTotalHP <= 0)
        {
            skeletonAnim.AnimationState.SetEmptyAnimation(0, 0.2f);
        }
        else
        {
            skeletonAnim.AnimationState.AddAnimation(0, "Idle", true, 1.0f);
        }
        CurrentTotalHP = Mathf.Max(CurrentTotalHP, 0);
    }

    public void Kill()
    {
        CurrentTotalHP = 0;
        Debug.Log("������ ����Ͽ����ϴ�.");
    }

    public float GetPartHPPercent(string name)
    {
        if (parts.ContainsKey(name))
            return parts[name].CurrentHP / (float)parts[name].MaxHP;
        return 0f;
    }

    public float GetTotalHPPercent()
    {
        return CurrentTotalHP / (float)MaxTotalHP;
    }

    public bool CanAttackPart(string name)
    {
        return parts.ContainsKey(name) && !parts[name].IsBroken;
    }

    public bool IsPartBroken(string name)
    {
        return parts.ContainsKey(name) && parts[name].IsBroken;
    }

    public int GetEvadeRate(string partName)
    {
        if (!parts.ContainsKey(partName)) return 0;
        return parts[partName].EvadeRate;
    }

    public List<string> GetAttackableParts()
    {
        List<string> result = new();
        foreach (var kv in parts)
        {
            if (!kv.Value.IsBroken)
                result.Add(kv.Key);
        }
        return result;
    }

    public void PerformAttack(TESTPlayer target)
    {
        if (isAttackDisabled)
        {
            Debug.Log("[Boss] ��� ���� �ı��Ǿ� ������ �� �����ϴ�.");
            return;
        }

        if (target == null || target.IsDead) return;

        int roll = Random.Range(0, 100);
        Debug.Log($"[Boss] ���� ����: {roll} vs ���� �ʿ�ġ: {hitChance}");

        if (roll >= hitChance)
        {
            Debug.Log("[Boss] ������ ���������ϴ�.");
            BossPartCombatManager.PlayDodgeSound();
            return;
        }

        target.TakeDamage(attackPower);
        Debug.Log($"[Boss] �÷��̾�� {attackPower} ������ ����!");
        BossPartCombatManager.PlayDamageSound();
    }

    public void PlayDeathAnimation()
    {
        var skeletonAnim = skeletonAnimation.GetComponent<SkeletonAnimation>();
        if (skeletonAnim != null)
        {
            skeletonAnim.AnimationState.SetEmptyAnimation(0, 0.2f);
            Debug.Log("[Boss] ���� �ִϸ��̼� ����");
        }
    }

    [System.Serializable]
    public class PartInfo
    {
        public string partName;
        public int hp;
        public string slotName;
        public int EvadeRate = 0;
    }

    public class MonsterPart
    {
        public string Name;
        public int MaxHP;
        public int CurrentHP;
        public int EvadeRate;
        public System.Action OnBreak;
        public bool IsBroken => CurrentHP <= 0;

        public MonsterPart(string name, int hp, int evadeRate, System.Action onBreak)
        {
            Name = name;
            MaxHP = hp;
            CurrentHP = hp;
            EvadeRate = evadeRate;
            OnBreak = onBreak;
        }

        public void Damage(int amount)
        {
            if (IsBroken) return;

            CurrentHP -= amount;
            CurrentHP = Mathf.Max(CurrentHP, 0);

            if (IsBroken)
            {
                OnBreak?.Invoke();
            }
        }
    }
}
