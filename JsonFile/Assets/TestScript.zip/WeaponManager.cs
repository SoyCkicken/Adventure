using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WeaponManager : MonoBehaviour
{
   public JsonManager jsonManager;
    public List<Weapon_Master> weapons;
    public Option_Master option_Master;
    public Weapon_Master currentweaponManager;
    //public TMP_Text text;
    public Transform contentParent;
    public GameObject weaponItemPrefab;

    void Start()
    {
        if (jsonManager == null)
            jsonManager = FindObjectOfType<JsonManager>();

        DisplayWeapons();
    }
    void DisplayWeapons()
    {
        // ���� UI �����
        foreach (Transform t in contentParent) Destroy(t.gameObject);

        foreach (var w in jsonManager.Weapon_Masters)
        {
            var go = Instantiate(weaponItemPrefab, contentParent);
            var header = go.transform.Find("Item Name+Icon");
            //var iconImg = header.Find("Icon").GetComponent<Image>();
            var nameTxt = header.Find("Name").GetComponent<TMP_Text>();
            nameTxt.text = w.Weapon_Name;
            // ������ �ε�
            var body = go.transform.Find("Item_Info");
            var statsTxt = body.Find("Stats").GetComponent<TMP_Text>();
            var optionsTxt = body.Find("Options").GetComponent<TMP_Text>();
            statsTxt.text = $"���ݷ�  {w.Weapon_DMG}\n";
            string STR, DEX, INT, MAG, DIV, CHR;
            if (w.STR_Scaling != 0)
            {
                statsTxt.text += "�� ����ġ : "+w.STR_Scaling.ToString() +"\n";
            }
            if (w.DEX_Scaling != 0)
            {
                statsTxt.text += "��ø ����ġ : " + w.DEX_Scaling.ToString() + "\n";
            }
            if (w.INT_Scaling != 0)
            {
                statsTxt.text += "���� ����ġ : " + w.INT_Scaling.ToString() + "\n";
            }
            if (w.MAG_Scaling != 0)
            {
                statsTxt.text += "���� ����ġ : " + w.MAG_Scaling.ToString() + "\n";
            }
            if (w.DIV_Scaling != 0)
            {
                statsTxt.text += "�ż� ����ġ : " + w.DIV_Scaling.ToString() + "\n";
            }
            if (w.CHR_Scaling != 0)
            {
                statsTxt.text += "ī������ ����ġ : " + w.CHR_Scaling.ToString() + "\n";
            }
            // �ɼ� ǥ��
            var myOpts = new List<string>();
            foreach (var opt in jsonManager.Item_Options)
            {
                //ù��° �ɼ�
                if (opt.Option_ID == w.Option_1_ID)
                    myOpts.Add($"{opt.Option_Description}");
                //�ι�° �ɼ�
                if(opt.Option_ID == w.Option_2_ID)
                    myOpts.Add($"{opt.Option_Description}");
            }

            // 4) Options �ؽ�Ʈ�� ����(��\n��)���� �ٿ������� ��!
            optionsTxt.text = myOpts.Count > 0
                ? string.Join("\n", myOpts)
                : "�ɼ� ����";
            var bodyRect = go.transform.Find("Item_Info").GetComponent<RectTransform>();

            // 1) ĵ���� ���̾ƿ� ������Ʈ ����
            Canvas.ForceUpdateCanvases();

            // 2) ���� ����
            LayoutRebuilder.ForceRebuildLayoutImmediate(bodyRect);
        }
    }
}


