using System.Collections.Generic;
using UnityEngine;

namespace MyGame.TextEffects
{
    public static class TextEffectParser
    {
        public static List<TextFragment> ParseFragments(string input)
        {
            var result = new List<TextFragment>();
            var effectStack = new Stack<TextEffect>();
            int i = 0;

            while (i < input.Length)
            {
                if (input[i] == '<')
                {
                    int tagEnd = input.IndexOf('>', i);
                    if (tagEnd == -1) break;

                    string tagContent = input.Substring(i + 1, tagEnd - i - 1).Trim();

                    // ���� �±�
                    if (tagContent.StartsWith("/"))
                    {
                        if (effectStack.Count > 0)
                            effectStack.Pop();
                        else
                            Debug.LogWarning($"[TextEffectParser] ���� �±� `{tagContent}`�� �߸��Ǿ����ϴ�.");

                        i = tagEnd + 1;
                        continue;
                    }

                    // ���� �±�
                    bool handled = false;

                    if (tagContent == "���̺�")
                    {
                        effectStack.Push(new TextEffect { type = EffectType.Wave });
                        handled = true;
                    }
                    else if (tagContent == "����")
                    {
                        effectStack.Push(new TextEffect { type = EffectType.Shake });
                        handled = true;
                    }
                    else if (tagContent.StartsWith("��:"))
                    {
                        string hex = tagContent.Substring(2);
                        if (!hex.StartsWith("#")) hex = "#" + hex;
                        if (ColorUtility.TryParseHtmlString(hex, out var col))
                        {
                            effectStack.Push(new TextEffect
                            {
                                type = EffectType.Color,
                                color = col
                            });
                            handled = true;
                        }
                        else
                        {
                            Debug.LogWarning($"[TextEffectParser] ���� �Ľ� ����: {hex}");
                        }
                    }

                    if (!handled)
                        Debug.LogWarning($"[TextEffectParser] �� �� ���� �±�: <{tagContent}>");

                    i = tagEnd + 1;
                }
                else
                {
                    int nextTag = input.IndexOf('<', i);
                    int len = (nextTag == -1 ? input.Length : nextTag) - i;
                    string text = input.Substring(i, len);
                    result.Add(new TextFragment(text, new List<TextEffect>(effectStack)));
                    i += len;
                }
            }

            return result;
        }
    }
}
