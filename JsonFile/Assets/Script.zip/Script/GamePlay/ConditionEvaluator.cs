using System;
using System.Collections.Generic;
using UnityEngine;

public static class ConditionEvaluator
{
    // ������Ʈ�� ���� �ν��Ͻ����� �޾Ƽ� �˻�
    public static bool Evaluate(
        List<ChoiceRequirement> reqs,
        PlayerState playerState,
        InventoryManager inventory,
        EquipmentSystem equipment,
        out List<string> reasons)
    {
        reasons = new List<string>();
        if (reqs == null || reqs.Count == 0) return true;

        foreach (var r in reqs)
        {
            if (r == null || string.IsNullOrEmpty(r.ID)) continue;

            var id = r.ID.Trim().ToUpperInvariant();
            var code = (r.Code ?? "").Trim();
            var val = r.Value;

            switch (id)
            {
                case "STAT":
                case "STATE":
                    if (GetStat(playerState, code) < val)
                        reasons.Add($"{code} {val}+ �ʿ�");
                    break;

                case "GOLD":
                    if (playerState.Experience < val)
                        reasons.Add($"��� {val}+ �ʿ�");
                    break;

                case "ITEM":
                    // ����: ���� Item_ID ��ü ������ �Ǵ�
                    if (inventory == null || inventory.CountItemInstances(code) < val)
                        reasons.Add($"{code} x{val}+ �ʿ�");
                    break;

                case "EQUIP":
                    // ���Ը�(Weapon/Armor) �Ǵ� Ư�����(Weapon:Weapon_001)
                    if (equipment == null || !equipment.MeetsEquipRequirement(code))
                        reasons.Add($"��� {code} �ʿ�");
                    break;

                default:
                    Debug.LogWarning($"[ConditionEvaluator] Unknown ID: {r.ID}");
                    break;
            }
        }

        return reasons.Count == 0;
    }

    // ���� �ڵ� �� �� ���� (���� ��Ģ�� ���� �ʿ�� ����)
    private static int GetStat(PlayerState ps, string code)
    {
        if (ps == null || string.IsNullOrEmpty(code)) return int.MinValue;
        switch (code.Trim().ToUpperInvariant())
        {
            case "STR": return ps.STR;
            case "AGI": return ps.AGI;
            case "INT": return ps.INT;
            case "MAG": return ps.MAG;
            case "DIV": return ps.DIV;
            case "CHA": return ps.CHA;
            case "HEALTH": return ps.Health;   // �ʿ�� CurrentHealth ������ ����
            case "MENTAL": return ps.INT;      // �� ��� ��Ģ�� �°� ��ü
            default: return int.MinValue;
        }
    }
}
