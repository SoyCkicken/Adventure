//using UnityEngine;

//public class GameFlowManager : MonoBehaviour
//{
//    // 1) ���� �帧 ���¸� ����
//    public enum FlowState
//    {
//        MainStory,
//        RandomEvent,
//        Battle
//    }

//    public FlowState currentState { get; private set; }

//    // 2) ���� �Ŵ��� ����
//    [Header("Managers")]
//    public StoryDisplayManager mainStoryManager;
//    public EventDisplay randomEventManager;
//    public CombatTest battleManager;

//    void Start()
//    {
//        // �ʱ� ����: ���� ���丮
//        EnterState(FlowState.MainStory);
//    }

//    // 3) ���� ��ȯ �޼���
//    public void EnterState(FlowState nextState)
//    {
//        ExitState(currentState);
//        currentState = nextState;

//        switch (currentState)
//        {
//            case FlowState.MainStory:
//                mainStoryManager.StartMainStory(OnMainStoryComplete);
//                break;
//            case FlowState.RandomEvent:
//                randomEventManager.StartRandomEvent(OnRandomEventComplete);
//                break;
//            case FlowState.Battle:
//                battleManager.StartBattle(OnBattleComplete);
//                break;
//        }
//    }

//    void ExitState(FlowState state)
//    {
//        // �ʿ� ��, ���� �Ŵ��� ���� ȣ��
//        switch (state)
//        {
//            case FlowState.MainStory:
//                mainStoryManager.StopMainStory();
//                break;
//            case FlowState.RandomEvent:
//                randomEventManager.StopRandomEvent();
//                break;
//            case FlowState.Battle:
//                battleManager.StopBattle();
//                break;
//        }
//    }

//    // 4) �ݹ鿡�� ���� �帧 ����
//    void OnMainStoryComplete()
//    {
//        // ���� ���丮 �� ����
//        EnterState(FlowState.Battle);
//    }

//    void OnRandomEventComplete(bool goToBattle)
//    {
//        if (goToBattle)
//            EnterState(FlowState.Battle);
//        else
//            EnterState(FlowState.MainStory);
//    }

//    void OnBattleComplete(bool playerWon)
//    {
//        // ���� ����� ���� ���ư� �� ����
//        if (mainStoryManager.IsCurrentlyPlaying)
//            EnterState(FlowState.MainStory);
//        else
//            EnterState(FlowState.RandomEvent);
//    }
//}
