using TMPro;
using UnityEngine;
using UnityEngine.U2D;
using UnityEngine.UI;
using static TMPro.SpriteAssetUtilities.TexturePacker_JsonArray;

public class ItemSlotUI : MonoBehaviour
{
    public Image icon;
    public Button button;
    private ItemData data;
    private System.Action<ItemData> onClickCallback;
    public SpriteBank spriteBank;
    public ItemData CurrentItem { get; set; }
    private void Awake()
    {
        button = this.GetComponent<Button>();
        button.onClick.AddListener(OnClick);
        if (spriteBank == null)
            spriteBank = FindObjectOfType<SpriteBank>();
    }

    public void Setup(ItemData item, System.Action<ItemData> onClick)
    {
        data = item;
        CurrentItem = item;
        onClickCallback = onClick;
        if (spriteBank == null)
            spriteBank = FindObjectOfType<SpriteBank>();

        //�̹��� ���� ����!
        if (!string.IsNullOrEmpty(item.Item_Name))
        {
            Debug.Log(item.Item_Name);
            if (icon == null)
            {
                Debug.LogError("[ItemSlotUI] icon(Image)�� �����Ϳ� ������� �ʾҽ��ϴ�.");
                return;
            }
            Sprite s = spriteBank.Load(item.Item_Name);
            if (s != null)
            {
                icon.sprite = s;
            }
        }
        else
        {
            icon.sprite = null;
        }
        
        //Debug.Log("������ ������ SetUp�� ȣ�� �Ǿ����ϴ�");
        //Debug.Log($"������ ������ Data �� ���Դϴ�{data}");
    }
    public void Clear()
    {
        data = null;
        icon.sprite = null;
        onClickCallback = null;
    }

    public void OnClick()
    {
        onClickCallback?.Invoke(data);
    }
}