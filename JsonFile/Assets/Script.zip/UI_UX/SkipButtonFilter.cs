using UnityEngine;

public class SkipButtonFilter : MonoBehaviour
{
    public RectTransform scrollViewRect;
    public System.Action onSkip;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 pos = Input.mousePosition;
            bool isOverScroll = RectTransformUtility.RectangleContainsScreenPoint(scrollViewRect, pos, null);
            
            if (!isOverScroll)
            {
                Debug.Log("��ŵ ����");
                onSkip?.Invoke();
            }
            else
            {
                if (Input.GetMouseButton(0))
                {
                   // this.gameObject.GetComponent<CanvasGroup>().blocksRaycasts = false;
                }
                Debug.Log("��ũ�� ���� ��ġ �� ����");
            }
        }
        if (Input.GetMouseButtonUp(0))
        {
            //this.gameObject.GetComponent<CanvasGroup>().blocksRaycasts = true;
        }
    }
}