using UnityEngine;
using System.Linq;
using MyGame;
using UnityEngine.UI;
using UnityEditor;
using System;  // Character, OptionContext ���� �ִ� ���ӽ����̽�

public class EquipmentSystem : MonoBehaviour
{
    public PlayerState playerState;
    public JsonManager jsonManager;
    public Character player;

    private void Start()
    {
        OptionManager.Initialize(jsonManager);
        //player.weapon_Name = null;
        //player.armor_Name = null;
        Init();
    }

    public void Init()
    {
        ClearInit();
        // �ڵ� ����
        if (jsonManager == null)
            jsonManager = FindObjectOfType<JsonManager>();
        var weapon = jsonManager.GetWeaponMasters("Weapon_Master")
                          .FirstOrDefault(w => w.Weapon_ID == player.weapon_Name);
        Debug.Log($"���� = {weapon != null}");
        // ���� ���� ó��
        if (weapon != null)
        {
            int tempDamage = Convert.ToInt32(weapon.Weapon_DMG + (playerState.STR * weapon.STR_Scaling)
                + (playerState.AGI * weapon.DEX_Scaling)
                + (playerState.INT * weapon.INT_Scaling)
                + (playerState.MAG * weapon.MAG_Scaling)
                + (playerState.CHA * weapon.CHR_Scaling)
                + (playerState.DIV * weapon.DIV_Scaling));
            player.damage = tempDamage;
            // �ɼ� ����Ʈ�� �߰�
            if (!string.IsNullOrEmpty(weapon.Option_1_ID))
                OptionManager.ApplyOption(weapon.Option_1_ID, new OptionContext
                {
                    User = player,
                    Value = weapon.Option_Value1,
                    item_ID = weapon.Weapon_ID,
                    option_ID = weapon.Option_1_ID
                });
            if (!string.IsNullOrEmpty(weapon.Option_2_ID))
                OptionManager.ApplyOption(weapon.Option_2_ID, new OptionContext
                {
                    User = player,
                    Value = weapon.Option_Value2,
                    item_ID = weapon.Weapon_ID,
                    option_ID = weapon.Option_2_ID
                });
        }
            var armor = jsonManager.GetArmorMasters("Armor_Master")
                             .FirstOrDefault(w => w.Armor_ID == player.armor_Name);
        Debug.Log($"�� = {armor != null}");
        // �� ���� ó��
        if (armor != null)
        {
            player.armor = armor.Armor_DEF;
            player.MaxHealth = armor.Armor_HP;
            // �ɼ� ����Ʈ�� �߰�
            if (!string.IsNullOrEmpty(armor.Armor_Option1))
                OptionManager.ApplyOption(armor.Armor_Option1, new OptionContext
                {
                    User = player,
                    Value = armor.Option1_Value,
                    item_ID = armor.Armor_ID,
                    option_ID = armor.Armor_Option1
                });
            if (!string.IsNullOrEmpty(armor.Armor_Option2))
                OptionManager.ApplyOption(armor.Armor_Option2, new OptionContext
                {
                    User = player,
                    Value = armor.Option2_Value,
                    item_ID = armor.Armor_ID,
                    option_ID = armor.Armor_Option2
                });
        }
    }
    void ClearInit()
    {
        Debug.LogError("�÷��̾� �ɷ�ġ �ʱ�ȭ");
        player.OnHitOptions.Clear();
        //player.weapon_Name = null;
        //player.armor_Name = null;
        player.MaxHealth = 50;
        player.damage = 10;
        player.armor = 10;
        player.speed = 1.5f;
        player.CitChance = 10;
    }
}

