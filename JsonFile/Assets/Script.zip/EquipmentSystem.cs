using UnityEngine;
using System.Linq;
using MyGame;
using UnityEngine.UI;
using UnityEditor;  // Character, OptionContext ���� �ִ� ���ӽ����̽�

public class EquipmentSystem : MonoBehaviour
{
    public JsonManager jsonManager;
    public Character player;
    public Character enemy;

    void Start()
    {
        // �ڵ� ����
        if (jsonManager == null)
            jsonManager = FindObjectOfType<JsonManager>();
        if (enemy == null)
            enemy = FindObjectOfType<Character>();
        var weapon = jsonManager.GetWeaponMasters("Weapon_Master")
                          .FirstOrDefault(w => w.Weapon_ID == player.weapon_Name);
        // ���� ���� ó��
        if (weapon != null)
        {
            player.damage += weapon.Weapon_DMG;
            // �ɼ� ����Ʈ�� �߰�
            if (!string.IsNullOrEmpty(weapon.Option_1_ID))
                player.OnHitOptions.Add(new Character.EquippedOption
                {
                    OptionID = weapon.Option_1_ID,
                    Value = weapon.Option_Value1,

                    item_ID = weapon.Weapon_Name

                });
            if (!string.IsNullOrEmpty(weapon.Option_2_ID))
                player.OnHitOptions.Add(new Character.EquippedOption
                {
                    OptionID = weapon.Option_2_ID,
                    Value = weapon.Option_Value2,
                    item_ID = weapon.Weapon_Name
                });
        }
        var armor = jsonManager.GetArmorMasters("Armor_Master")
                         .FirstOrDefault(w => w.Armor_ID == player.armor_Name);
        // �� ���� ó��
        if (armor != null)
        {
            player.armor += armor.Armor_DEF;
            player.Health += armor.Armor_HP;
            // �ɼ� ����Ʈ�� �߰�
            if (!string.IsNullOrEmpty(armor.Armor_Option1))
                player.OnHitOptions.Add(new Character.EquippedOption
                {
                    OptionID = armor.Armor_Option1,
                    Value = armor.Option1_Value,
                    item_ID = armor.Armor_NAME
                });
            if (!string.IsNullOrEmpty(armor.Armor_Option2))
                player.OnHitOptions.Add(new Character.EquippedOption
                {
                    OptionID = armor.Armor_Option2,
                    Value = armor.Option2_Value,
                    item_ID = armor.Armor_ID
                });
        }

        //void ApplyWeaponOptions(Weapon_Master w)
        //{
        //    // �ɼ� 1
        //    if (!string.IsNullOrEmpty(w.Option_1_ID))
        //    {
        //        //var ctx = new OptionContext
        //        //{
        //        //    User = player,
        //        //    Target = player,           // �нú� �ɼ��̶�� �ڱ� �ڽ��� Ÿ������
        //        //    Value = w.Option_Value1,
        //        //    // DamageDealt, TurnNumber ���� �ɼǿ� ���� ä���ָ� ��
        //        //};
        //        //optionManager.ApplyOption(w.Option_1_ID, ctx);
        //        player.Option1_ID = w.Option_1_ID;
        //        player.Option1_Value = w.Option_Value1;
        //    }

        //    // �ɼ� 2
        //    if (!string.IsNullOrEmpty(w.Option_2_ID))
        //    {
        //        //var ctx = new OptionContext
        //        //{
        //        //    User = player,
        //        //    Target = player,
        //        //    Value = w.Option_Value2,
        //        //};
        //        //optionManager.ApplyOption(w.Option_2_ID, ctx);
        //        player.Option2_ID = w.Option_2_ID;
        //        player.Option2_Value = w.Option_Value2;
        //    }
    }
}

