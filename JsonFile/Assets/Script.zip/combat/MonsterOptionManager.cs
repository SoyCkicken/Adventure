using System.Collections;
using System.Collections.Generic;
using MyGame;
using UnityEngine;

public class MonsterOptionManager : MonoBehaviour
{
    public JsonManager jsonManager;
    private Dictionary<string, IOptionEffect> effects;

    void Awake()
    {
        if (jsonManager == null)
            jsonManager = FindObjectOfType<JsonManager>();

        effects = new Dictionary<string, IOptionEffect>();
        // ���Ϳ� �ɼǸ� ���
        // ��: Roar, PoisonCloud �� ���� ����
        effects["MonEffect_001"] = new MonsterRoarEffect();
        //effects["MonEffect_002"] = new PoisonCloudEffect();
        // ���ʿ��� ��ŭ
    }

    public void ApplyMonsterOption(string optionID, OptionContext ctx)
    {
        Debug.Log($"���� �ɼ��� �̸� = {optionID}");
        if (effects.TryGetValue(optionID, out var e))
            e.Apply(ctx);
        else
            Debug.LogWarning($"MonsterOptionManager: �̵�� OptionID={optionID}");
    }
}
