using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;
using Palmmedia.ReportGenerator.Core.Reporting.Builders;
using System.Linq;
using static Unity.VisualScripting.FlowStateWidget;

public class RemoteTester : MonoBehaviour
{
    [Header("���� ī�װ��� ��ư")]
    public Button mainStoryButton;
    public Button randomStoryButton;
    public Button battleButton;
    public Button weaponTestButton;
    public Button reMoveButton;
    public Button armorTestButton;

    [Header("������ ��ư ������ �� �θ�")]
    public GameObject buttonPrefab;
    public Transform rightPanelParent;

    [Header("���ν��丮 , �̺�Ʈ , �� ���� ����")]
    public StoryDisplayManager storyDisplayManager;
    public EventDisplay eventDisplay;
    public GameFlowManager gameFlowManager;
    public InventoryManager inventoryManager;
    public JsonManager jsonManager;

    // ���� �ó����� / �� ID ����Ʈ
    private List<string> mainStories = new List<string> { "MainScene_1", "MainScene_2", "MainScene_3", "MainScene_4" ,"MainScene_5"};
    private List<string> randomStories = new List<string> { "EventScene_1", "EventScene_2", "EventScene_3", "EventScene_4" };
    private List<string> enemyIDs = new List<string> { "monster_001", "monster_002", "monster_003" };
    private List<string> WeaponID = new List<string>();
    private List<string> ArmorID = new List<string>();
    private List<ItemData> WeaponitemData = new List<ItemData>();
    private List<ItemData> ArmoritemData = new List<ItemData>();

    private void Start()
    {
        var allWeapons = jsonManager.GetWeaponMasters("Weapon_Master").ToList();
        foreach (var weapon in allWeapons)
        {
            WeaponID.Add(weapon.Weapon_ID);
            WeaponitemData.Add(new ItemData { Item_ID = weapon.Weapon_ID, Item_Name = weapon.Weapon_Name, Item_Type = weapon.ItemType });
        }
        var allArmors = jsonManager.GetArmorMasters("Armor_Master").ToList();
        foreach (var armor in allArmors)
        {
            ArmorID.Add(armor.Armor_ID);
            ArmoritemData.Add(new ItemData { Item_ID = armor.Armor_ID, Item_Name = armor.Armor_NAME, Item_Type = armor.ItemType });
        }
        mainStoryButton.onClick.AddListener(() => ShowOptions(mainStories, OnMainStorySelected));
        randomStoryButton.onClick.AddListener(() => ShowOptions(randomStories, OnRandomStorySelected));
        battleButton.onClick.AddListener(() => ShowOptions(enemyIDs, OnBattleSelected));
        weaponTestButton.onClick.AddListener(() => ShowOptions(WeaponID, WeaponAddInventory));
        armorTestButton.onClick.AddListener(() => ShowOptions(ArmorID, ArmorAddInventory));
        reMoveButton.onClick.AddListener(() => RemoveAllInventory());
    }

    // ������ �г� ��ư ����
    void ShowOptions(List<string> options, System.Action<string> onClickAction)
    {
        // ���� ��ư ����
        foreach (Transform child in rightPanelParent)
            Destroy(child.gameObject);

        // ���ο� ��ư ����
        foreach (var option in options)
        {
            GameObject btnObj = Instantiate(buttonPrefab, rightPanelParent);
            btnObj.GetComponentInChildren<TMP_Text>().text = option;

            btnObj.GetComponent<Button>().onClick.AddListener(() => onClickAction(option));
        }
    }

    // �� �׸� Ŭ�� �� ����
    void OnMainStorySelected(string groupID)
    {
        if (int.TryParse(groupID.Replace("MainScene_", ""), out int id))
        {
            Debug.Log($"[������] ���� �̺�Ʈ ���� ����: �׷� ID = {id}");
            //�ϴ� ���� ��Ű�� ����
            storyDisplayManager.StopMainStory();
            eventDisplay.StopRandomEvent();
            storyDisplayManager.storyList.Clear();
            eventDisplay.groupEvents.Clear();
            FindObjectOfType<StoryDisplayManager>().LoadMainStory(id);
        }

    }

    void OnRandomStorySelected(string groupID)
    {
        if (int.TryParse(groupID.Replace("EventScene_", ""), out int id))
        {
            Debug.Log($"[������] ���� �̺�Ʈ ���� ����: �׷� ID = {id}");
            //�ϴ� ���� ��Ű�� ����
            storyDisplayManager.StopMainStory();
            eventDisplay.StopRandomEvent();
            storyDisplayManager.storyList.Clear();
            eventDisplay.groupEvents.Clear();
            FindObjectOfType<EventDisplay>().LoadEventStory(id);
        }
    }

    void OnBattleSelected(string enemyID)
    {
        Debug.Log($"[������] ���� ����: {enemyID}");
        storyDisplayManager.StopMainStory();
        eventDisplay.StopRandomEvent();
        storyDisplayManager.storyList.Clear();
        eventDisplay.groupEvents.Clear();
        FindObjectOfType<GameFlowManager>().ForceBattleWithMonster(enemyID);
    }
    void WeaponAddInventory(string weaponID)
    {
        Debug.Log($"[������] ������ �߰� ����: {weaponID}");
        var itemData = WeaponitemData.FirstOrDefault(i => i.Item_ID == weaponID);
        if (itemData != null)
        {
            inventoryManager.AddItemToInventory(itemData);
        }
        else
        {
            Debug.LogError($"[������] ���� {weaponID}�� ItemData�� ã�� �� �����ϴ�.");
        }
    }
    void ArmorAddInventory(string armorID)
    {
        Debug.Log($"[������] ������ �߰� ���� : {armorID}");
        var itemData = ArmoritemData.FirstOrDefault(i => i.Item_ID == armorID);
        if (itemData != null)
        {
            inventoryManager.AddItemToInventory(itemData);
        }
    }

    void RemoveAllInventory()
    {
        Debug.Log("[������] �κ��丮�� �ִ� ��� ������ ����");
        //inventoryManager.ClearAllItems();
    }
}