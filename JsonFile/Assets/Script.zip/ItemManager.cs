using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ExcelDataReader.Log;

public class ItemManager : MonoBehaviour
{
    [Header("JSON Manager")]
    public JsonManager jsonManager;

    [Header("Content Parents")]
    [Header("���� UI ��ġ�� �� �������� �ϴ� �ؽ�Ʈ ��� ��ġ�� ������ ������ �س���")]
    //��ġ�ε� �ϴ� �ϳ��� ����
    public Transform weaponsParent;
    //public Transform armorsParent;
    //public Transform consumablesParent;

    [Header("Item Prefabs")]
    [Header("�̰� ���� ��񸶴� ��� �ؾ� �Ǵ� ���� �޶����ų� �ϸ� �����ո� ���� �߰� ���ָ� ��")]
    public GameObject weaponItemPrefab;
    public GameObject armorItemPrefab;
    public GameObject consumableItemPrefab;

    void Start()
    {
        //jsonManager�� ������ִ��� Ȯ���ϰ� ����������� ���� ã�Ƽ� ����
        if (jsonManager == null)
            jsonManager = FindObjectOfType<JsonManager>();
        //����Ѵ�
        DisplayWeapons();
        DisplayArmors();
        DisplayConsumables();
    }
    //�����ϴµ� 
    void Clear(Transform parent)
    {
        foreach (Transform t in parent)
            Destroy(t.gameObject);
    }

    void DisplayWeapons()
    {
        //Clear(weaponsParent);
        foreach (var w in jsonManager.GetWeaponMasters("Weapon_Master"))
        {
            var go = Instantiate(weaponItemPrefab, weaponsParent);
            // Header �����۹��� ���κ��̶� ���
            var header = go.transform.Find("Item Name+Icon");
            header.Find("Name").GetComponent<TMP_Text>().text = w.Weapon_Name;
            // Body: Stats �����۹��� �߰� �κ��̶� �ٵ�
            var body = go.transform.Find("Item_Info");
            var stats = body.Find("Stats").GetComponent<TMP_Text>();
            //�ؽ�Ʈ �߰�
            stats.text = $"���ݷ� {w.Weapon_DMG}\n";
            if (w.STR_Scaling != 0) stats.text += $"�� ����ġ : {w.STR_Scaling}\n";
            if (w.DEX_Scaling != 0) stats.text += $"��ø ����ġ : {w.DEX_Scaling}\n";
            if (w.INT_Scaling != 0) stats.text += $"���� ����ġ : {w.INT_Scaling}\n";
            if (w.MAG_Scaling != 0) stats.text += $"���� ����ġ : {w.MAG_Scaling}\n";
            if (w.DIV_Scaling != 0) stats.text += $"�ż� ����ġ : {w.DIV_Scaling}\n";
            if (w.CHR_Scaling != 0) stats.text += $"ī������ ����ġ : {w.CHR_Scaling}\n";
            // Body: Options
            var opts = body.Find("Options").GetComponent<TMP_Text>();
            var myOpts = new List<string>();
            if (!string.IsNullOrEmpty(w.Option_1_ID))
            {
                var o = jsonManager.GetOptionMasters("Option_Master").FirstOrDefault(x => x.Option_ID == w.Option_1_ID);
                if (o != null) myOpts.Add($"{o.Option_Description} +{w.Option_Value1}");
            }
            if (!string.IsNullOrEmpty(w.Option_2_ID))
            {
                var o = jsonManager.GetOptionMasters("Option_Master").FirstOrDefault(x => x.Option_ID == w.Option_2_ID);
                if (o != null) myOpts.Add($"{o.Option_Description} +{w.Option_Value2}");
            }
            opts.text = myOpts.Count > 0 ? string.Join("\n", myOpts) : "�ɼ� ����";

            ForceRebuild(body);
        }
    }

    void DisplayArmors()
    {
        //Clear(weaponsParent);
        foreach (var a in jsonManager.GetArmorMasters("Armor_Master"))
        {
            var go = Instantiate(armorItemPrefab, weaponsParent);
            var header = go.transform.Find("Item Name+Icon");
            header.Find("Name").GetComponent<TMP_Text>().text = a.Armor_NAME;

            var body = go.transform.Find("Item_Info");
            var stats = body.Find("Stats").GetComponent<TMP_Text>();
            stats.text = $"���� {a.Armor_DEF}\nü�� {a.Armor_HP}";

            var opts = body.Find("Options").GetComponent<TMP_Text>();
            var myOpts = new List<string>();
            if (!string.IsNullOrEmpty(a.Armor_Option1))
            {
                var o = jsonManager.GetOptionMasters("Option_Master").FirstOrDefault(x => x.Option_ID == a.Armor_Option1);
                if (o != null) myOpts.Add($"{o.Option_Description} +{a.Option1_Value}");
            }
            if (!string.IsNullOrEmpty(a.Armor_Option2))
            {
                var o = jsonManager.GetOptionMasters("Option_Master").FirstOrDefault(x => x.Option_ID == a.Armor_Option2);
                if (o != null) myOpts.Add($"{o.Option_Description} +{a.Option2_Value}");
            }
            opts.text = myOpts.Count > 0 ? string.Join("\n", myOpts) : "�ɼ� ����";

            ForceRebuild(body);
        }
    }

    void DisplayConsumables()
    {
        //Clear(weaponsParent);
        foreach (var it in jsonManager.GetItemMasters("Item_Master"))
        {
            var go = Instantiate(consumableItemPrefab, weaponsParent);
            var header = go.transform.Find("Item Name+Icon");
            header.Find("Name").GetComponent<TMP_Text>().text = it.Item_NAME;

            var body = go.transform.Find("Item_Info");
            var stats = body.Find("Stats").GetComponent<TMP_Text>();
            stats.text = $"{it.Item_Description}\n����: {it.Item_Price}";

            var opts = body.Find("Options").GetComponent<TMP_Text>();
            var myOpts = new List<string>();
            if (!string.IsNullOrEmpty(it.Item_Option1))
            {
                var o = jsonManager.GetOptionMasters("Option_Master").FirstOrDefault(x => x.Option_ID == it.Item_Option1);
                if (o != null) myOpts.Add($"{o.Option_Description} +{it.Option1_Value}");
            }
            if (!string.IsNullOrEmpty(it.Item_Option2))
            {
                var o = jsonManager.GetOptionMasters("Option_Master").FirstOrDefault(x => x.Option_ID == it.Item_Option2);
                if (o != null) myOpts.Add($"{o.Option_Description} +{it.Option2_Value}");
            }
            opts.text = myOpts.Count > 0 ? string.Join("\n", myOpts) : "�ɼ� ����";

            ForceRebuild(body);
        }
    }

    void ForceRebuild(Transform body)
    {
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(body.GetComponent<RectTransform>());
    }
}
